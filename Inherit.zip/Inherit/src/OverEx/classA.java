package OverEx;

public class classA {
    int i;
    int j;
    
    public classA(){
    }
    
    public void show(){
        System.out.println("i: " + i);
        System.out.println("j: " + j);
    }
    
    
}