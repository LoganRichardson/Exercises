package inherit;

public class Mouse {

    public void leftClick() {
        System.out.println("Click!");
    }

    public void rightClick() {
        System.out.println("Click!");
    }

    public void connect() {
        System.out.println("connected");
    }

    public void scrollUp() {
        System.out.println("scrolled up");
    }

    public void scrollDown() {
        System.out.println("scrolled down");
    }
}
