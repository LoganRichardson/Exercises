package inherit;

public class Mouse3 extends Mouse{
    
    boolean ambidextrous = true;

     
}