package inherit;

public class Mouse2 extends Mouse {
     public void connect(){
         System.out.println("connected");
     }
}