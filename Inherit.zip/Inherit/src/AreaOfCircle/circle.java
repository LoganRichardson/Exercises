package AreaOfCircle;

public class circle extends area{
    public void area(){
        double area = areaCalc();
        System.out.println("Radius " + radius + " and Area is " + area);
    }
}