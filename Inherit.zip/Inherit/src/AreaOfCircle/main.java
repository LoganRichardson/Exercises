package AreaOfCircle;

public class main {
    
    public static void main(String[] args) {
        tempMethod();
    }
    public static void tempMethod(){
        circle method = new circle();
        method.area();
    }
}