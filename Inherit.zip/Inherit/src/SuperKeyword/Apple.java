package SuperKeyword;

public class Apple {
    int number_of_items;
}